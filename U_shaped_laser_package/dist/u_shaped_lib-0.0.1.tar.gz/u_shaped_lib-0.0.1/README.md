A package where all classes and methods used in data analysis and plots are stored.

To install it use the command: pip install path/to/where/uslib/is/stored

So for example if current location is at PICLAB_NARROW_LINEWIDTH, then the path should be ./U_shaped_laser_package