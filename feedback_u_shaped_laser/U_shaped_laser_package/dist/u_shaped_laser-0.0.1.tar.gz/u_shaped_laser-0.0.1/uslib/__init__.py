'''from . import load_data, fit_functions, data_processing

ld = load_data.LoadData()
ff = fit_functions.FitFunctions()
dp = data_processing.DataProcessing()'''